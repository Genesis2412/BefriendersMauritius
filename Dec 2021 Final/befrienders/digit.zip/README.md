# Digicup 2020

Hiresh Pandoo @Genesis2412
*******************************************************************************
[Completed]
connection.php  --- connection database
             index.sql --- table details for homepage sections
index.php       --- Homepage
    index.css   ___ css file for index
    
 style.css      --- css file for signin and signup
 
 hbackend.css   --- css file for ueraccount.php
 
 signup.php     --- signup page
 
 signin.php     --- signin page 
 
 checksessionLogin.php --- warns user if login invalid
 
 processsignup.php   ---  
 
 server.php      --- Receiving all input values from form to create user
 
 useraccount.php  ---- users are able to add testimonials and update their passwords.
 
 logout.php       ---  destroy session by logging out
 


array.php       --- querying database in a 2D array(home + testimonials)

swapsec.php     --- page displaying all details of section + update button
    hbackend.css___ css for modal
fetchsec.php    --- get all values of data to be changed in homepage
uploadimg.php   --- upload image(png, jpeg, jpg) to folder
updatesec.php   --- updating details by id

testiform.php   --- form for user to add testimonials
testimonial.php --- page to display form
    hbackend.css___ css for form
addtesti.php    --- script to add testimonials in database
            testimonial.sql --- table details for testimonials


admin.php --- admin interface
admin.css --- style for admin page
addstaff.php --- form to add staff, update info of staff and delete staff
insert.php --- insert data from staff form to database
delete.php --- delete data from form to database
update.php --- update data from form to database


 MainArticle.html -- Display All Article Catalog(Modify the nav bar href)
 
 Article.php -- Specific Article on click(moify the nav bar href)
 
 Events.html --Display ALl events catalog(Modify the nav bar href)
 
 MyEvent.php --Specific Event on click(Modify the nav bar href)
 

*******************************************************************************
[Pending]
sections a tags not working properly

***PA DELETE NANIER LOR ZOT WORKSPACE***
*******************************************************************************

