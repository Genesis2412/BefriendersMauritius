$.getJSON("http://api.openweathermap.org/data/2.5/forecast?q=London,uk&APPID=e069060414189a5c27cc92f460d30c3f", function(data){

console.log(data);

})